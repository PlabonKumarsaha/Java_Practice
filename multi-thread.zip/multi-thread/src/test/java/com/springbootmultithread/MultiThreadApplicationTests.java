package com.springbootmultithread;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MultiThreadApplicationTests {

	@Test
	void contextLoads() {
	}

}
